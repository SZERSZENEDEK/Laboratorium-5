package com.example.kalkulatorppk

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val brutto = findViewById<EditText>(R.id.et_brutto)
        val wiek = findViewById<EditText>(R.id.et_wiek)
        val koniec = findViewById<EditText>(R.id.et_rok_koniec)
        val results = findViewById<TextView>(R.id.tv_resuls)
        val calculate = findViewById<Button>(R.id.bt_calculate)
        val chip_group_ee = findViewById<ChipGroup>(R.id.cg_myself)
        val chip_group_er = findViewById<ChipGroup>(R.id.cg_employer)

        val constant_ee_percent = 2.0
        val constant_er_percent = 1.5
        var saldo = 0.0

        // kasa na koniec
        fun calculate_profit(gross:Double, age:Double, end:Double): Double{

            val checkedTopicList_ee = arrayListOf<Double>()

            chip_group_ee.setOnCheckedStateChangeListener{group, checkedIds_ee ->
                if (checkedIds_ee.isEmpty()){
                    // do nothing
                }else{
                    checkedTopicList_ee.clear()
                    checkedIds_ee.forEach{idx ->
                        val chip = findViewById<Chip>(idx)
                        checkedTopicList_ee.add(chip.text.toString().toDouble())
                    }
                    var ee_pc_ = checkedTopicList_ee[0]
                }
            }

            val checkedTopicList_er = arrayListOf<Double>()

            chip_group_er.setOnCheckedStateChangeListener{group, checkedIds_er ->
                if (checkedIds_er.isEmpty()){
                    // do nothing
                }else{
                    checkedTopicList_er.clear()
                    checkedIds_er.forEach{idx ->
                        val chip = findViewById<Chip>(idx)
                        checkedTopicList_er.add(chip.text.toString().toDouble())
                    }
                    var er_pc_ = checkedTopicList_er[0]
                }
            }
            saldo = 0.0
            val final_percentage = ee_pc + er_pc + constant_er_percent + constant_ee_percent // procent wpłat na konto
            val monthly_payment = gross * (final_percentage/100)
            val yearly_input = monthly_payment*12


            for (i in age.toInt()..end.toInt()){
                saldo += yearly_input
                val odsetki = saldo * 0.05
                saldo += odsetki
            }
            return saldo
        }
        /**
        var ee_pc_ = 0.0
        for (i in 0 until chip_group_ee.childCount) {
        val chip = chip_group_ee.getChildAt(i) as Chip
        if (chip.isChecked) {
        ee_pc_ = chip.text.toString().replace("%", "").toDouble()
        }
        }

        var er_pc_ = 0.0
        for (i in 0 until chip_group_er.childCount) {
        val chip = chip_group_er.getChildAt(i) as Chip
        if (chip.isChecked) {
        er_pc_ = chip.text.toString().replace("%", "").toDouble()
        }
        }
         **/



        calculate.setOnClickListener {
            val gross_ = brutto.text.toString().toDoubleOrNull()
            val age_ = wiek.text.toString().toDoubleOrNull()
            val end_ = koniec.text.toString().toDoubleOrNull()

            if (gross_ == null || age_ == null || end_ == null) {
                results.text = "Uzupełnij poprawnie wszystkie dane!"
                return@setOnClickListener
            }

            val wynik = calculate_profit(gross_, age_, end_, ee_pc_, er_pc_)
            results.text = "Po ${end_ - age_} latach oszczędzania\nuzyskano %.2f zł".format(wynik)
        }
    }
}